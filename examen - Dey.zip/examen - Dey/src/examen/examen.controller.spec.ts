import { Test, TestingModule } from '@nestjs/testing';
import { AppController } from './Examen.controller';
import { ExamenService } from './Examen.service';

describe('AppController', () => {
  let appController: AppController;

  beforeEach(async () => {
    const app: TestingModule = await Test.createTestingModule({
      controllers: [AppController],
      providers: [ExamenService],
    }).compile();

    
  });


});
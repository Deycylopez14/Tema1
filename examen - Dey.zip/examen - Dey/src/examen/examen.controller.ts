import { Get, Controller, Render } from '@nestjs/common';
import { ExamenService } from './examen.service';

@Controller('/no')
export class AppController {
  constructor(private appService: ExamenService) {}

  @Get('/')
  @Render('index') 
  hello() {
    return { message: 'WAOO!' };
  }

  @Get('examen')
  @Render('examen')
  root() {
    return { message: 'Hello world!' };
  }
}